from datetime import datetime


# ========================
#        PERSON CLASS
# ========================
class Person:
    def __init__(
        self, full_name, birth_place, nationality, birth_year, birth_month, birth_day,
        height_cm, gender, address, profession, phone, emergency_contact, emergency_phone
    ):
        self.full_name = full_name
        self.birth_place = birth_place
        self.nationality = nationality
        self.birth_year = birth_year
        self.birth_month = birth_month
        self.birth_day = birth_day
        self.height_cm = height_cm
        self.gender = gender
        self.address = address
        self.profession = profession
        self.phone = phone
        self.emergency_contact = emergency_contact
        self.emergency_phone = emergency_phone

    def get_age(self, year=2025):
        return year - self.birth_year

    def get_height_inches(self):
        return self.height_cm / 2.54

    def is_adult(self):
        return self.get_age() >= 18


# ========================
#     ID CARD CLASS
# ========================
class IDCard:
    def __init__(self, person: Person):
        self.person = person
        self.issue_date = datetime.now()
        self.expire_date = self.issue_date.replace(year=self.issue_date.year + 10)
        self.id_number = self.generate_id()

    def generate_id(self):
        return (
            f"{self.person.full_name[:3].upper()}"
            f"{self.person.birth_year}"
            f"{self.person.birth_month:02d}"
            f"{self.person.birth_day:02d}"
        )

    def display(self):
        p = self.person
        age = p.get_age()
        inches = p.get_height_inches()
        status = "ADULT" if p.is_adult() else "MINOR"

        issue = self.issue_date.strftime("%d/%m/%Y")
        expiration = self.expire_date.strftime("%d/%m/%Y")

        width = 60  # frame width

        print("\n" + "┌" + "─" * width + "┐")
        print("│{:^{w}}│".format("NATIONAL IDENTITY CARD", w=width))
        print("├" + "─" * width + "┤")

        print(f"│ FULL NAME          : {p.full_name:<{width-22}}│")
        print(f"│ DATE OF BIRTH      : {p.birth_day:02d}/{p.birth_month:02d}/{p.birth_year:<{width-22}}│")
        print(f"│ BIRTH PLACE        : {p.birth_place:<{width-22}}│")
        print(f"│ NATIONALITY        : {p.nationality:<{width-22}}│")
        print(f"│ AGE / STATUS       : {age} yrs - {status:<{width-29}}│")
        print(f"│ HEIGHT             : {p.height_cm} cm / {inches:.1f} in{'':<{width-33}}│")
        print(f"│ GENDER             : {p.gender:<{width-22}}│")
        print(f"│ PROFESSION         : {p.profession:<{width-22}}│")
        print(f"│ PHONE              : {p.phone:<{width-22}}│")
        print(f"│ ADDRESS            : {p.address:<{width-22}}│")
        print(f"│ EMERGENCY CONTACT  : {p.emergency_contact:<{width-22}}│")
        print(f"│ EMERGENCY PHONE    : {p.emergency_phone:<{width-22}}│")

        print("├" + "─" * width + "┤")
        print(f"│ ID NUMBER          : {self.id_number:<{width-22}}│")
        print(f"│ ISSUED ON          : {issue:<{width-22}}│")
        print(f"│ EXPIRATION         : {expiration:<{width-22}}│")

        print("└" + "─" * width + "┘")


# ========================
#      CARD MANAGER
# ========================
class IDCardGenerator:
    def __init__(self):
        self.cards = []

    def collect_person_data(self):
        fields = [
            "full name", "birth place", "nationality",
            "birth year", "birth month", "birth day",
            "height in cm", "gender (M/F)", "address", "profession",
            "phone number", "emergency contact person",
            "emergency contact phone"
        ]

        person_data = []

        for field in fields:
            while True:
                val = input(f"Enter your {field}: ")

                if field == "birth year":
                    try:
                        val = int(val)
                        if val < 1900 or val > 2025:
                            print("Error: Invalid year")
                            continue
                    except:
                        print("Error: Invalid year")
                        continue

                elif field == "birth month":
                    try:
                        val = int(val)
                        if val < 1 or val > 12:
                            print("Error: Invalid month")
                            continue
                    except:
                        print("Error: Invalid month")
                        continue

                elif field == "birth day":
                    try:
                        val = int(val)
                        if val < 1 or val > 31:
                            print("Error: Invalid day")
                            continue
                    except:
                        print("Error: Invalid day")
                        continue

                elif field == "height in cm":
                    try:
                        val = float(val)
                    except:
                        print("Error: Invalid height")
                        continue

                elif field == "gender (M/F)":
                    if val.upper() not in ["M", "F"]:
                        print("Error: Invalid gender")
                        continue

                person_data.append(val)
                break

        return Person(*person_data)

    def generate_cards(self):
        n = int(input("How many cards to create? "))

        for i in range(n):
            print(f"\n=== Creating card {i+1}/{n} ===")
            person = self.collect_person_data()
            card = IDCard(person)
            self.cards.append(card)
            card.display()

    def show_all(self):
        if not self.cards:
            print("No cards generated.")
            return

        for i, card in enumerate(self.cards, 1):
            print(f"\n----- CARD {i} -----")
            card.display()


# ========================
#       MAIN PROGRAM
# ========================
def main():
    gen = IDCardGenerator()

    while True:
        print("\n=== MENU ===")
        print("1 • Create ID cards")
        print("2 • Show all cards")
        print("3 • Quit")

        c = input("Choice: ")

        if c == "1":
            gen.generate_cards()
        elif c == "2":
            gen.show_all()
        elif c == "3":
            print("Goodbye!")
            break
        else:
            print("Invalid option.")


if __name__ == "__main__":
    main()
